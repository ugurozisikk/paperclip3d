# Paperclip 3D Ofis

Paperclip şirketiniz için canlı 3D ofis, ajan detayları ve görev tahtası.

**Kurulum ve kullanım:** [KURULUM.md](KURULUM.md)

Paket derlenmiştir; bağımlılık kurmaya veya derlemeye gerek yoktur.
Şirketler ve ajanlar otomatik okunur. Büyük ekiplerde birden fazla kat kullanılır.
Ajan çalıştırmaz veya görev değiştirmez; ek model çağrısı yapmaz.
Tüm sahne dosyaları Paperclip sunucunuzdan yüklenir.

Test edilen Paperclip: 2026.1023.0. Node.js: 24+.

Görsel temel: [The Roving Office](https://github.com/atlassian-labs/roving-office).
Bağımsız topluluk uyarlamasıdır; resmi Paperclip veya Atlassian ürünü değildir.
Lisanslar ve atıflar pakete dahildir.
