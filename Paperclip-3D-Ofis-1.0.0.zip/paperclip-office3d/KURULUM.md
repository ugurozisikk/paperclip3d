# Paperclip 3D Ofis — kurulum

Bu paket, Paperclip içindeki şirketleri canlı bir 3D ofis olarak gösterir.
Her şirketin ajanlarını, yönetici ilişkilerini ve görevlerini kendisi okur.
Yeni şirket için ayrıca kod veya API anahtarı girmeniz gerekmez.

## Gereksinimler

- Çalışır durumda bir Paperclip sunucusu ve eklenti yükleyebilen yönetici hesabı.
- Node.js 24 veya üzeri.
- WebGL destekleyen güncel bir tarayıcı.
- Doğrulanan Paperclip sürümü: **2026.1023.0**. Diğer sürümler için uyumluluk garantisi yoktur.

## Yerel bilgisayar

1. ZIP'i açın. İçindeki `paperclip-office3d` klasörünü kalıcı bir yere taşıyın.
2. Bu klasörün bulunduğu üst klasörde terminal açın.
3. Çalışan Paperclip sunucunuza eklentiyi yükleyin:

```sh
npx paperclipai plugin install ./paperclip-office3d --local --api-base http://127.0.0.1:3100
```

Paperclip CLI'niz kuruluysa `npx paperclipai` yerine `paperclipai` kullanabilirsiniz.
Eklentiyi yükleyen CLI sürümünün sunucunuzun sürümüyle eşleşmesi önerilir.
Oturum gerektiren kurulumlarda CLI'nin normal yönetici giriş akışını tamamlayın.

4. Paperclip sayfasını yenileyin ve bir şirket seçin.
5. Sol menüden **3D Ofis** ekranını açın.

Paket derlenmiştir; `npm install` veya derleme yapmanız gerekmez.
Yerel klasör üzerinden yüklendiği için klasörü kurulumdan sonra silmeyin veya taşımayın.
Paperclip'i farklı bir adreste çalıştırıyorsanız `--api-base` değerini değiştirin.

## Docker veya başka sunucu

Klasör, Paperclip sunucusunun dosya sisteminde bulunmalıdır. Docker kullanıyorsanız
klasörü konteynere bağlayın ve yükleme sırasında konteyner içindeki yolu kullanın.
Kendi bilgisayarınızdaki yol uzak sunucuda geçerli değildir.
Yönetilen/hosted Paperclip hizmetleri üçüncü taraf eklenti kurulumunu kısıtlayabilir.

## Kullanım

- Şirket değiştirdiğinizde o şirketin ekibi ve görevleri gelir.
- Kat başına beş ajan gösterilir; büyük ekipler için kat seçici görünür.
- Bir kişiye tıklayın: yöneticisi ve mevcut görevi açılır.
- Görev kartları Paperclip'teki gerçek göreve gider.
- Veriler yaklaşık üç saniyede bir yenilenir.
- Açık ekran sırasında görülen görev devirleri ve tamamlamalar iş akışına düşer.
- Devir animasyonu, iki kişi de görünür kattaysa oynar.
- Tam ekran, gündüz/akşam ve görünümü sıfırlama düğmeleri kullanılabilir.

Eklenti görüntüleme içindir. Ajan başlatmaz, görev oluşturmaz ve onay vermez.
Görselleştirme için ek model/API kullanımı yoktur. Mevcut ajanlarınızın kendi kullanım
ücretleri ve sınırları Paperclip'te aynen geçerlidir.
Uzak Roving Office hizmetine veri göndermez; sahne ve veriler Paperclip sunucunuzdan gelir.

## Kapatma

Paperclip'in eklenti ayarlarından **3D Ofis** eklentisini devre dışı bırakabilirsiniz.
Bu işlem şirketlerinizi veya görevlerinizi silmez.

## Lisans ve destek

Bağımsız bir topluluk uyarlamasıdır. Apache-2.0 altında dağıtılır; üçüncü taraf
lisans ve atıfları paket içindeki `LICENSE`, `NOTICE` ve `THIRD_PARTY_NOTICES.txt`
dosyalarında bulunur. Bunları yeniden dağıtılan kopyalarda koruyun.
Görsel temel: https://github.com/atlassian-labs/roving-office

Bu ilk paylaşım sürümüdür. Sorun bildirirken Paperclip sürümünüzü, tarayıcınızı ve
hata ekranını paylaşın; API anahtarı veya hassas şirket verisi paylaşmayın.
